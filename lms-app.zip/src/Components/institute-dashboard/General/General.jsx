import React from 'react'
import DashBoard from '../dashboard/dashboard'
import TestStatusBar from '../dashboard/teststaus/teststatus'

const General = () => {
  return (
    <div>
      <DashBoard />
      <TestStatusBar />
     




    </div>
  )
}

export default General