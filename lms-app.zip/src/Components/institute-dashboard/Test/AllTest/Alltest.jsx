import React from 'react'
import './AllTest.css'
import TopBar from '../../class-batch/classtopbar/classtopbar';
import TestIndex from '../TestIndex/TestIndex';

const Alltest = () => {
  return (
    <div>
    
   
    <TestIndex />
    </div>
  );
}

export default Alltest